<?php

   $baza = "mysql.agh.edu.pl:3306";
   $login = "login";
   $haslo = "haslo";
   $database_name = "nazwa_bazy_danych";
   
   $admin_login = "administrator";
   $admin_haslo = "haslo";

?>