            <ul id="menu">
              <li><a href="index.php?page=news"  <?php if ($page==news) print 'class="current"' ?>>Aktualności</a></li>
			  <li><a href="index.php?page=epatient"  <?php if ($page==epatient) print 'class="current"' ?>>ePatient</a></li>
			  <li><a href="index.php?page=gps"  <?php if ($page==gps) print 'class="current"' ?>>Lokalizacja GPS</a></li>
			  <li><a href="index.php?page=photos"  <?php if ($page==photos) print 'class="current"' ?>>Zdjęcia</a></li>
            </ul >

